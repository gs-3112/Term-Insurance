package com.ti.model;

import java.time.Instant;

import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;

@Entity
@Getter
@Setter
@Table(name = "TEducationalQualification")
public class TEducationalQualification {

	@Id
	@Column(name = "eduQualId")
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Integer eduQualId;
	
	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "person_id")
	private TCustomer personId;
	
	@Column(name = "createdBy")
	private String createdBy;
	
	@Column(name = "createdDate")
	@CreatedDate
	private Instant createdDate;

	@Column(name = "modifiedBy")
	private String modifiedBy;
	
	@Column(name = "modifiedDate")
	@LastModifiedDate
	private Instant modifiedDate;

	@Column(name="active")
	boolean active;

}
