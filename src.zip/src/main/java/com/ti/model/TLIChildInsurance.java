package com.ti.model;

import java.time.Instant;

import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;

@Entity
@Getter
@Setter
@Table(name="TLIChildInsurance")
public class TLIChildInsurance {

	@Id
	@Column(name = "LIChildId")
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Integer liChildId;
	
	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "person_id")
	private TCustomer personId;
	
	@Column(name = "childName")
	private String childName;
	
	@Column(name="childAge")
	private Integer childAge;
	
	@Column(name="goalType")
	private String goalType;
	
	@Column(name="goalAmt")
	private Double goalAmt;
	
	@Column(name="goalTenure")
	private Integer goalTenure;
	
	@Column(name="expensesFinal")
	private Double expensesFinal;

	@Column(name="years")
	private Integer years;

	@Column(name="saveAmount")
	private Double saveAmount;

	@Column(name="tenure")
	private Integer tenure;

	@Column(name = "createdDate")
	@CreatedDate
	private Instant createdDate;

	@Column(name = "modifiedBy")
	private String modifiedBy;
	
	@Column(name = "modifiedDate")
	@LastModifiedDate
	private Instant modifiedDate;

	@Column(name="active")
	boolean active;

	
}
