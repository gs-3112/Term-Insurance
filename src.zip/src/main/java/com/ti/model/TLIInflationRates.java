package com.ti.model;

import java.time.Instant;

import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;

@Entity
@Getter
@Setter
@Table(name = "TLIInflationRates")
public class TLIInflationRates {

	@Id
	@Column(name = "LIInflationRateId",nullable = false)
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Integer liInflationRateId;
	
	@Column(name="LIInflationRate")
	private Integer liInflationRate;
	
	@Column(name = "createdBy")
	private String createdBy;
	
	@Column(name = "createdDate")
	@CreatedDate
	private Instant createdDate;

	@Column(name = "modifiedBy")
	private String modifiedBy;
	
	@Column(name = "modifiedDate")
	@LastModifiedDate
	private Instant modifiedDate;

	@Column(name="active")
	boolean active;



}
