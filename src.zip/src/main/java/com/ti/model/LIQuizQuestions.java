package com.ti.model;

import java.time.Instant;

import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;
import lombok.Getter;
import lombok.Setter;

@Entity
@Getter
@Setter
@Table(name = "TLIQuizQuestions", uniqueConstraints = @UniqueConstraint(name = "uk_quiz_questions_id", columnNames = "liQuestionId"))
public class LIQuizQuestions {

	@Id
	@Column(name = "liQuestionId",nullable = false)
	@GeneratedValue(strategy=GenerationType.TABLE)
	private Integer liQuestionId;
	
	@Column(name = "LIQuestions")
	private String liQuestions;
	
	@Column(name = "LIOption1")
	private String liOption1;

	@Column(name = "LIOption2")
	private String liOption2;
	
	@Column(name = "LIOption3")
	private String liOption3;

	@Column(name = "LIOption4")
	private String liOption4;
	
	@Column(name = "LIAnswers")
	private String lIAnswers;
	
	@Column(name = "createdBy")
	private String createdBy;
	
	@Column(name = "createdDate")
	@CreatedDate
	private Instant createdDate;

	@Column(name = "modifiedBy")
	private String modifiedBy;
	
	@Column(name = "modifiedDate")
	@LastModifiedDate
	private Instant modifiedDate;

	@Column(name="active")
	boolean active;

	

}
