package com.ti.model;

import java.time.Instant;

import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Getter
@Setter
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_EMPTY)
@NoArgsConstructor
@Table(name="TLICustTermInsurance")
public class TLICustTermInsurance {

	@Id
	@Column(name="custTermInsID", nullable = false)
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Integer custTermInsID;
	
	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "id")
	private TCustomer id;

	@Column(name="insuredFor")
	private String insuredFor;
	
	@Column(name="count")
	private Integer count;
	
	@Column(name="age")
	private Integer age;
	
	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name="eduQualId")
	private TEducationalQualification eduQualId;
	
	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name="occupationId")
	private TOccupationType occupationId;
	
	@Column(name="locationPin")
	private Integer locationPin;
	
	@Column(name="liabilities")
	private short liabilities;
	
	@Column(name="liabilityAmount")
	private double liabilityAmount;
	
	@Column(name="existingCover")
	private short existingCover;

	@Column(name="existingCoverAmt")
	private double existingCoverAmt;
	
	@Column(name="policyName")
	private String policyName;
	
	@Column(name="maxEligCover")
	private double maxEligCover;
	
	@Column(name="selectedCover")
	private double selectedCover;
	
	@Column(name="yearlyPremium")
	private double yearlyPremium;
	
	@Column(name = "createdDate")
	@CreatedDate
	private Instant createdDate;

	@Column(name = "modifiedBy")
	private String modifiedBy;
	
	@Column(name = "modifiedDate")
	@LastModifiedDate
	private Instant modifiedDate;

	@Column(name="active", nullable = false)
	boolean active;

	public Integer getCustTermInsID() {
		return custTermInsID;
	}

	public void setCustTermInsID(Integer custTermInsID) {
		this.custTermInsID = custTermInsID;
	}

	public TCustomer getId() {
		return id;
	}

	public void setId(TCustomer id) {
		this.id = id;
	}

	public String getInsuredFor() {
		return insuredFor;
	}

	public void setInsuredFor(String insuredFor) {
		this.insuredFor = insuredFor;
	}

	public Integer getCount() {
		return count;
	}

	public void setCount(Integer count) {
		this.count = count;
	}

	public Integer getAge() {
		return age;
	}

	public void setAge(Integer age) {
		this.age = age;
	}

	public TEducationalQualification getEduQualId() {
		return eduQualId;
	}

	public void setEduQualId(TEducationalQualification eduQualId) {
		this.eduQualId = eduQualId;
	}

	public TOccupationType getOccupationId() {
		return occupationId;
	}

	public void setOccupationId(TOccupationType occupationId) {
		this.occupationId = occupationId;
	}

	public Integer getLocationPin() {
		return locationPin;
	}

	public void setLocationPin(Integer locationPin) {
		this.locationPin = locationPin;
	}

	public short getLiabilities() {
		return liabilities;
	}

	public void setLiabilities(short liabilities) {
		this.liabilities = liabilities;
	}

	public double getLiabilityAmount() {
		return liabilityAmount;
	}

	public void setLiabilityAmount(double liabilityAmount) {
		this.liabilityAmount = liabilityAmount;
	}

	public short getExistingCover() {
		return existingCover;
	}

	public void setExistingCover(short existingCover) {
		this.existingCover = existingCover;
	}

	public double getExistingCoverAmt() {
		return existingCoverAmt;
	}

	public void setExistingCoverAmt(double existingCoverAmt) {
		this.existingCoverAmt = existingCoverAmt;
	}

	public String getPolicyName() {
		return policyName;
	}

	public void setPolicyName(String policyName) {
		this.policyName = policyName;
	}

	public double getMaxEligCover() {
		return maxEligCover;
	}

	public void setMaxEligCover(double maxEligCover) {
		this.maxEligCover = maxEligCover;
	}

	public double getSelectedCover() {
		return selectedCover;
	}

	public void setSelectedCover(double selectedCover) {
		this.selectedCover = selectedCover;
	}

	public double getYearlyPremium() {
		return yearlyPremium;
	}

	public void setYearlyPremium(double yearlyPremium) {
		this.yearlyPremium = yearlyPremium;
	}

	public Instant getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Instant createdDate) {
		this.createdDate = createdDate;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public Instant getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(Instant modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public boolean isActive() {
		return active;
	}

	public void setActive(boolean active) {
		this.active = active;
	}


	
	
	
}
