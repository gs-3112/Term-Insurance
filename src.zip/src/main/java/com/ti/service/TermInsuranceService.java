package com.ti.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.ti.dao.OccupationTypeRepository;
import com.ti.dao.TermInsuranceRepository;
import com.ti.model.TLICustTermInsurance;
import com.ti.model.TOccupationType;

public class TermInsuranceService implements ITermInsuranceService{

	@Autowired
	TermInsuranceRepository tiRepo;
	
	@Autowired
	OccupationTypeRepository occupationRepo;
	
	public List<TLICustTermInsurance> getTermInsuranceDetails(int customerId) {
		return tiRepo.findAll();
	}

	public TLICustTermInsurance addTermInsuranceDetails(TLICustTermInsurance termInsuranceDetails) {
		return tiRepo.save(termInsuranceDetails);
	}

	public List<TOccupationType> getAllOccupations() {
		List<TOccupationType> list = occupationRepo.findAll();
		for (TOccupationType tOccupationType : list) {
			System.out.println("tOccupationType :"+tOccupationType.getOccupationType());
		}
		return list;
	}
		
}
