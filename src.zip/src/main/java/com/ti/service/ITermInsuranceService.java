package com.ti.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.ti.model.TLICustTermInsurance;
import com.ti.model.TOccupationType;

@Service
public interface ITermInsuranceService {

	List<TLICustTermInsurance> getTermInsuranceDetails(int customerId);
	TLICustTermInsurance addTermInsuranceDetails(TLICustTermInsurance termInsuranceDetails);
	List<TOccupationType> getAllOccupations();
}
