package com.ti.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ti.model.TLICustTermInsurance;
import com.ti.model.TOccupationType;
import com.ti.service.ITermInsuranceService;

@RestController
@RequestMapping("/termplan")
public class LITermInsuranceController {

	@Autowired
	ITermInsuranceService tiService;

		
	@GetMapping("{customerId}")
	public List<TLICustTermInsurance> getTermInsuranceDetails(@PathVariable int customerId) {
		return tiService.getTermInsuranceDetails(customerId);
	}
	
	@PostMapping
	public TLICustTermInsurance addTermInsuranceDetails(@RequestBody TLICustTermInsurance termInsuranceDetails) {
		return tiService.addTermInsuranceDetails(termInsuranceDetails);
	}
	
	@GetMapping("/occupations")
	public List<TOccupationType> getAllOccupations() {
		return tiService.getAllOccupations();
	}

}

